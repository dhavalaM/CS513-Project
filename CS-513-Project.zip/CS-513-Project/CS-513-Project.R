#  Course          : CS 513
#  First Name      : Devanshu
#  Last Name       : Mehta
#  Id              : 10421645
#  Project         : Young people survey
#  Team            : Devanshu, Sowmya, Dhavala 

rm(list = ls())
library(randomForest)

responses <- read.csv("C:/Devanshu/Study/KDDM/Datasets/responses_random_forest.csv", na.strings = "")
responses1 <- na.omit(responses)

str(responses1)
View(responses1)
nrow(responses1)

set.seed(123)

index <- seq (1,nrow(responses1),by=2)
test<-responses1[index,]
training<-responses1[-index,]

output <- randomForest(Alcohol~., data = training, importance=TRUE, ntree=1000)
importance(output)
varImpPlot(output)
plot(output)
print(output)

Prediction <- predict(output, test)
table(actual=test[,45],Prediction)

wrong<-(test[,45]!=Prediction)
error_rate<-sum(wrong)/length(wrong)
error_rate
